  'use strict';

  function gotKey (event) {
      
      var key = event.key;
      
      // Do something based on key press
      
      // create a new shape and do a redo a draw
      draw();
  }
  
